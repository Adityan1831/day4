'use strict'
var category = ["electronics", "clothing", "books", "toys",];
var product = [{
    name: "iphone 15",
    price: "$499",
    path: "https://store.storeimages.cdn-apple.com/1/as-images.apple.com/is/iphone-15-model-unselect-gallery-1-202309?wid=5120&hei=2880&fmt=webp&qlt=70&.v=aVFiZEF4WDEvUWJNSU5HRDg4cklnTGdzSmpObkZCM3MrNmJ5SkhESlNDZ1UwRE05YU1MZ0lYWk55ZU5FOENXWkpFd0xhWDVibStLdGRYRmxkNGI4VTdpMGJRT0ppMjh4RlRZQkc0Q3FZZEI4UW55RWdXT3BFc2NrR2VEb1pCOGo&traceId=1"

},
{
    name: "iphone 15 pro",
    price: "$599",
    path: "https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/iphone-card-40-iphone16prohero-202409?wid=680&hei=528&fmt=p-jpg&qlt=95&.v=1725567335931"
},
{
    name: "iphone 15 pro max",
    price: "$999",
    path: "https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/iphone-card-40-iphone16prohero-202409?wid=680&hei=528&fmt=p-jpg&qlt=95&.v=1725567335931"
},
{
    name: "iphone 15 PLUS",
    price: "$699",
    path: "https://store.storeimages.cdn-apple.com/4668/as-images.apple.com/is/iphone-card-40-iphone15hero-202309?wid=680&hei=528&fmt=p-jpg&qlt=95&.v=1693086290559"
},

]
category && category.length > 0 && 
    category.forEach( function ( v , i ){
    console.log( v , i );
    var listing =document.createElement("li");
    console.log(listing);
    listing.innerHTML= v;
    document.querySelector("ul").append(listing);
});
product && product.length > 0 && product.forEach( function ( v , i ){
    console.log( v , i );
    var divtag =document.createElement("div");
    console.log(divtag);

    divtag.className="col-md-3 text-center"; 
    var imgtag =document.createElement("img");
    var h2tag =document.createElement("h2");
    var ptag =document.createElement("p");

    imgtag.src = v.path;
    imgtag.className="IMG-FLUID";
    h2tag.innerHTML = v.price;
    ptag.innerHTML=v.name  
    divtag.append(imgtag,h2tag,ptag);

    document.getElementById("row").append(divtag);
})