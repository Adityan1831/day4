'use strict';
class auth{
    constructor(){
        this.details = [
            {
                email : "adi1@gmail.com",
                password :"Adi@1212"
            },
            {
                email : "shiddhant@gmail.com",
                password :"Adi@1312"
            },
            {
                email : "darshan@gmail.com",
                password :"Adi@1412"
            },
        ];
    }
    checkemail(emailid){
        console.log(emailid);
        var exp=/^([a-zA-Z0-9]+)@([a-zA-Z0-9]+)\.([a-zA-Z]{2,})(\.[]{2,})?$/
        var result=exp.test(emailid);
        console.log(result);    
        return result;
    }
checkpass(pass){
    
    console.log(pass);
     var exp=/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[@#\$]).{4,12}$/
    var result1 =exp.test(pass);
    console.log(result1);
    return result1;

}
checkemailandpass(){

}

}
export default auth;