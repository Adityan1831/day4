import auth from './library.js';

document.querySelector('button').onclick= function(){
    alert("Thik h re aaba!");
    var data1= document.getElementById('x1').value;
    var data2= document.getElementById('x2').value;
    // console.log(data1);
    // console.log(data2);
    var authobj=new auth();
    console.log(authobj)
    var ans = authobj.checkemail(data1);
    console.log(ans)
    var ans2 = authobj.checkpass(data2);
    console.log(ans2)
    if(ans  &&  ans2){
        document.querySelector('p').innerHTML="Form submitted successfully!";
    }
    else{
        document.querySelector('p').innerHTML="Inavlid Password or Email!";
    }
}